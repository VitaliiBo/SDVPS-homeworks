# Ansible Collection - mafalb.apache


|||
|---|---|
|master|![master branch](https://github.com/mafalb/ansible-collection-apache/workflows/CI/badge.svg?branch=master)|
|dev|![dev branch](https://github.com/mafalb/ansible-collection-apache/workflows/CI/badge.svg?branch=dev)|


Ansible collection mafalb.apache

## Roles

### [mafalb.apache.httpd](roles/httpd/README.md)

## License

Copyright (c) 2021 Markus Falb <markus.falb@mafalb.at>

GPL-3.0-or-later
